<template>

</template>

<style lang="scss">

</style>

<script>
    export default {
        data() {
            return {

            }
        },
        methods: {

        }
    }
</script>